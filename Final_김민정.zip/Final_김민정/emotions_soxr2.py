# n_steps(Pitch shifting), playback_speed(Tempo), effect_type(Reverb, Delay, WahWah), filter_type(High-pass, Low-pass)
# By soxr

import cv2
import numpy as np
from keras.models import load_model
from keras.optimizers import Adam
from statistics import mode
import pyaudio
import librosa
import threading
import signal
import sys
import soxr
from scipy.signal import butter, lfilter

# Emotion model setup
emotion_model_path = './models/emotion_model.hdf5'
emotion_labels = ['angry', 'disgust', 'fear', 'happy', 'sad', 'surprise', 'neutral']

# Hyper-parameters for webcam and model
frame_window = 10
emotion_offsets = (20, 40)

# Load emotion model
emotion_classifier = load_model(emotion_model_path, compile=False)
optimizer = Adam(learning_rate=0.0001)
emotion_classifier.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])
emotion_target_size = emotion_classifier.input_shape[1:3]

# Webcam and face detection setup
face_cascade = cv2.CascadeClassifier('./models/haarcascade_frontalface_default.xml')

# Emotion analysis variables
emotion_window = []
current_emotion = 'neutral'

# PyAudio setup for real-time audio processing
CHUNK = 512
FORMAT = pyaudio.paFloat32
CHANNELS = 1
RATE = 44100

# PyAudio streams
p = pyaudio.PyAudio()

# Load input audio file
audio_file = './melody1.wav'
samples, sr = librosa.load(audio_file, sr=RATE)

# Stop flag for threads
stop_threads = False

# Signal handler for Ctrl+C
def signal_handler(sig, frame):
    global stop_threads
    stop_threads = True
    print("Exiting gracefully...")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

# Helper functions for filters and effects
def butter_filter(audio, cutoff, filter_type, order=2):
    nyquist = 0.5 * RATE
    normalized_cutoff = cutoff / nyquist
    b, a = butter(order, normalized_cutoff, btype=filter_type, analog=False)
    return lfilter(b, a, audio)

def reverb(audio, decay=0.1, delay=0.03):
    delay_samples = int(RATE * delay)
    reverb_audio = np.copy(audio)
    for i in range(delay_samples, len(audio)):
        reverb_audio[i] += decay * audio[i - delay_samples]
    return np.clip(reverb_audio, -1.0, 1.0)

def wah_wah(audio, freq=0.2, depth=0.05):
    modulator = np.sin(2 * np.pi * freq * np.arange(len(audio)) / RATE) * depth + 1
    return audio * modulator

def preprocess_input(x, v2=True):
    x = x.astype('float32')
    x = x / 255.0
    if v2:
        x = x - 0.5
        x = x * 2.0
    return x

def apply_offsets(face_coordinates, offsets):
    x, y, w, h = face_coordinates
    x_off, y_off = offsets
    return x - x_off, x + w + x_off, y - y_off, y + h + y_off

def draw_bounding_box(face_coordinates, image, color):
    x, y, w, h = face_coordinates
    cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)

def draw_text(face_coordinates, image, text, color, x_offset=0, y_offset=0, font_scale=1, thickness=2):
    x, y, w, h = face_coordinates
    cv2.putText(image, text, (x + x_offset, y + y_offset), cv2.FONT_HERSHEY_SIMPLEX,
                font_scale, color, thickness, cv2.LINE_AA)

def process_audio(data, n_steps, playback_speed, effect_type, filter_type):
    audio = np.frombuffer(data, dtype=np.float32)
    
    # Adjust pitch using soxr's resample
    pitch_factor = 2 ** (n_steps / 12)
    new_rate = int(RATE * pitch_factor)
    pitched_audio = soxr.resample(audio, RATE, new_rate)

    # Adjust tempo using soxr
    tempo_rate = int(new_rate / playback_speed)
    stretched_audio = soxr.resample(pitched_audio, new_rate, tempo_rate)

    # Apply filter
    if filter_type == "Low-pass":
        filtered_audio = butter_filter(stretched_audio, cutoff=1500, filter_type='low')  # Soft low-pass
    elif filter_type == "High-pass":
        filtered_audio = butter_filter(stretched_audio, cutoff=200, filter_type='high')  # Soft high-pass
    else:
        filtered_audio = stretched_audio

    # Apply effects
    if effect_type == "Reverb":
        effect_audio = reverb(filtered_audio, decay=0.05, delay=0.02)  # Subtle reverb
    elif effect_type == "Wah-Wah":
        effect_audio = wah_wah(filtered_audio, freq=0.3, depth=0.1)  # Gentle Wah-Wah
    else:
        effect_audio = filtered_audio

    # Clip the audio to avoid overflow
    processed_audio = np.clip(effect_audio, -1.0, 1.0)

    # Resize to CHUNK size for playback
    return np.resize(processed_audio, (CHUNK,))

def audio_stream():
    global stop_threads, current_emotion
    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    output=True,
                    frames_per_buffer=CHUNK)

    position = 0
    while not stop_threads and position + CHUNK < len(samples):
        # Emotion-based settings
        if current_emotion == 'happy':
            n_steps, playback_speed, effect_type, filter_type = 2, 1.2, "Reverb", "High-pass"
        elif current_emotion == 'sad':
            n_steps, playback_speed, effect_type, filter_type = -2, 0.9, "Wah-Wah", "Low-pass"
        elif current_emotion == 'angry':
            n_steps, playback_speed, effect_type, filter_type = 3, 1.1, "Reverb", "High-pass"
        elif current_emotion == 'surprise':
            n_steps, playback_speed, effect_type, filter_type = 2, 1.3, "Reverb", "High-pass"
        else:  # neutral
            n_steps, playback_speed, effect_type, filter_type = 0, 1.0, "None", "None"

        chunk = samples[position:position + CHUNK]
        position += CHUNK
        processed_audio = process_audio(chunk.tobytes(), n_steps, playback_speed, effect_type, filter_type)
        stream.write(processed_audio.tobytes())

    stream.stop_stream()
    stream.close()

def detect_emotion():
    global stop_threads, current_emotion
    cv2.namedWindow('Emotion Detection')
    cap = cv2.VideoCapture(0)

    while not stop_threads:
        ret, bgr_image = cap.read()
        if not ret:
            break

        gray_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2GRAY)
        rgb_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)

        faces = face_cascade.detectMultiScale(
            gray_image, scaleFactor=1.1, minNeighbors=5,
            minSize=(30, 30), flags=cv2.CASCADE_SCALE_IMAGE
        )

        for face_coordinates in faces:
            x1, x2, y1, y2 = apply_offsets(face_coordinates, emotion_offsets)
            gray_face = gray_image[y1:y2, x1:x2]
            try:
                gray_face = cv2.resize(gray_face, emotion_target_size)
            except:
                continue

            gray_face = preprocess_input(gray_face, True)
            gray_face = np.expand_dims(gray_face, 0)
            gray_face = np.expand_dims(gray_face, -1)
            emotion_prediction = emotion_classifier.predict(gray_face)
            emotion_label_arg = np.argmax(emotion_prediction)
            emotion_text = emotion_labels[emotion_label_arg]
            emotion_window.append(emotion_text)

            if len(emotion_window) > frame_window:
                emotion_window.pop(0)

            current_emotion = mode(emotion_window)

            draw_bounding_box(face_coordinates, rgb_image, (0, 255, 0))
            draw_text(face_coordinates, rgb_image, emotion_text, (0, 255, 0), 0, -45, 1, 1)

        bgr_image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)
        cv2.imshow('Emotion Detection', bgr_image)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# Start threads
emotion_thread = threading.Thread(target=detect_emotion)
audio_thread = threading.Thread(target=audio_stream)

emotion_thread.start()
audio_thread.start()

emotion_thread.join()
audio_thread.join()

# Close PyAudio
p.terminate()
